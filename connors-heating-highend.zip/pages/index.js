export default function Home() {
  return (
    <div style={{ fontFamily: "Arial, sans-serif", margin: 0 }}>

      <header style={nav}>
        <div style={navInner}>
          <strong>Connor’s Heating</strong>
          <div>
            <a href="tel:07502223708" style={navBtn}>Call</a>
            <a href="https://go.servicem8.com/request_quote" style={navPrimary}>Get Quote</a>
          </div>
        </div>
      </header>

      <section style={hero}>
        <h1 style={heroTitle}>
          Boiler Repair & Plumbing<br />in County Durham, UK
        </h1>
        <p style={heroSub}>
          Fast response. Honest pricing. Gas Safe registered engineers.
        </p>

        <div style={{ marginTop: 30 }}>
          <a href="https://go.servicem8.com/request_quote">
            <button style={btnPrimary}>Get Free Quote</button>
          </a>

          <a href="tel:07502223708">
            <button style={btnSecondary}>Call Now</button>
          </a>
        </div>
      </section>

      <section style={trustBar}>
        <p>✔ Gas Safe Registered • ✔ 5★ Rated • ✔ Same-Day Service</p>
      </section>

      <section style={section}>
        <h2 style={heading}>Our Services</h2>
        <div style={grid}>
          {services.map((s, i) => (
            <div key={i} style={card}>
              <h3>{s}</h3>
              <p style={{ fontSize: "14px", opacity: 0.7 }}>
                Professional, reliable service you can trust.
              </p>
            </div>
          ))}
        </div>
      </section>

      <section style={section}>
        <h2 style={heading}>Find Us</h2>
        <iframe
          src="https://www.google.com/maps?q=County%20Durham&output=embed"
          width="100%"
          height="350"
          style={{ border: 0, borderRadius: "12px" }}
        />
      </section>

      <section style={cta}>
        <h2>Need Help Fast?</h2>
        <a href="https://go.servicem8.com/request_quote">
          <button style={btnPrimary}>Request Quote</button>
        </a>
      </section>

      <footer style={footer}>
        Connor’s Heating Ltd © {new Date().getFullYear()}<br/>
        Gas Safe Registered Engineers (UK)
      </footer>

    </div>
  );
}

const services = [
  "Boiler Repairs",
  "Boiler Servicing",
  "Boiler Installation",
  "Bathrooms",
  "General Plumbing"
];

const nav = { position:"sticky", top:0, background:"#fff", borderBottom:"1px solid #eee"};
const navInner = {maxWidth:"1100px",margin:"auto",padding:"15px",display:"flex",justifyContent:"space-between"};
const navBtn = {marginRight:"10px",textDecoration:"none",color:"#000"};
const navPrimary = {padding:"8px 14px",background:"#2563eb",color:"#fff",borderRadius:"6px",textDecoration:"none"};

const hero = {background:"linear-gradient(135deg,#0f172a,#1e293b)",color:"#fff",padding:"100px 20px",textAlign:"center"};
const heroTitle = {fontSize:"38px"};
const heroSub = {opacity:0.8};

const trustBar = {background:"#f1f5f9",textAlign:"center",padding:"10px"};

const section = {padding:"60px 20px",textAlign:"center"};
const heading = {fontSize:"26px",marginBottom:"20px"};

const grid = {display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:"20px"};
const card = {border:"1px solid #eee",borderRadius:"12px",padding:"20px"};

const cta = {background:"#111",color:"#fff",padding:"60px 20px",textAlign:"center"};
const footer = {background:"#000",color:"#fff",padding:"20px",textAlign:"center"};

const btnPrimary = {padding:"12px 20px",margin:"8px",border:"none",borderRadius:"8px",background:"#2563eb",color:"#fff"};
const btnSecondary = {...btnPrimary,background:"#16a34a"};
